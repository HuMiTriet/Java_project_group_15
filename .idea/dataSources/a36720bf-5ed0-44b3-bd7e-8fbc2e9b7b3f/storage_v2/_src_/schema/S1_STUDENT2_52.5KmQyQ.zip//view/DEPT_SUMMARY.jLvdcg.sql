create view DEPT_SUMMARY (D, C, TOTAL_S, AVERAGE_S) as
SELECT Dno, COUNT (*), SUM (Salary), AVG (Salary)
FROM
EMPLOYEE
GROUP BY Dno
/

