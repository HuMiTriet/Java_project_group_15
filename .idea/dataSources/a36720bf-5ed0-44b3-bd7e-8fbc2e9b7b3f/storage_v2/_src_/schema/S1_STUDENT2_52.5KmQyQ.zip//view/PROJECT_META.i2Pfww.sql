create view PROJECT_META as
select p.pname as project_name, d.dname as con_dept, count(w.essn) as no_emp, sum(w.hours) as hours
from project p
    join department d on (p.dnum = d.dnumber)
    join works_on w on (w.pno = p.pnumber)
group by p.pname, d.dname
/

