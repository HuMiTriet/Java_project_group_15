create view RE_EMP as
select e.lname, m.lname as super_lname, e.salary, d.dname
from employee e
    join department d on (d.dnumber = e.dno)
    join department_metadata m on (m.dname = d.dname)
where d.dname = 'Research' and e.lname != m.lname
/

