create view DEPARTMENT_METADATA as
select d.dname, e.lname, e.salary
from employee e 
    join department d on (e.ssn = d.mgrssn)
/

