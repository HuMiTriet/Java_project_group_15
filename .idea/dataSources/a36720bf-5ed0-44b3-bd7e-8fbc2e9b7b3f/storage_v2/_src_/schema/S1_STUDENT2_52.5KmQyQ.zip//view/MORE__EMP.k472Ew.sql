create view MORE__EMP as
select "PROJECT_NAME","CON_DEPT","NO_EMP","HOURS" 
from project_meta
where no_emp >1
/

